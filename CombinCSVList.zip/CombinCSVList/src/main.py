import sys
from csv import DictWriter
from csv import DictReader
from time import time

def main():
    startTime = time()
    csv_readerNew, csv_readerOld, csvFileNew, csvFileOld = getReaders()
    print("Working on it")
    newFile = open('PC_Upgrade_List_new.csv', 'w')
    fieldNames = ['🖥️ My Office','Don\'t Do','Done','First Contact','Last contact','Contact','Notes','Account info : Assessed','Computer','Serial number','Account info : AssetTagID','Connected user','Model','Account info : Department','Account info : Expiration Date','IP address','Last inventory','Operating system']
    csv_writer = DictWriter(newFile, fieldnames=fieldNames, delimiter=',')
    csv_writer.writeheader()
    for row_new in csv_readerNew:
        found = False
        row = {}
        for row_old in csv_readerOld:
            if row_old['Computer'] == row_new['Computer'] and row_old['Account info : Expiration Date'] == row_new['Account info : Expiration Date']:
                writeKnownRow(row_new, row_old, row)
                csv_writer.writerow(row)
                found = True
                break
        if not found:
            writeUnknownRow(row_new, row)
            csv_writer.writerow(row)
    csvFileNew.close()
    csvFileOld.close()
    newFile.close()
    endTime = time()
    print("Seconds: {:0.2f}".format(endTime - startTime))
    print("PC_Upgrade_List_new.csv has been created")

def getReaders():
    csvFileNew = ''
    csvFileOld = ''
    if len(sys.argv) < 2 or len(sys.argv) > 3:
        usage("Invalid number of arguments.", 1)
    try:
        csvFileNew = open(sys.argv[1])
    except FileNotFoundError as e:
        usage(f"Invalid new file: {e.filename}", 2)
    try:
        csvFileOld = open(sys.argv[2])
    except FileNotFoundError as e:
        usage(f"Invalid old file: {e.filename}", 3)
    csv_readerNew = DictReader(csvFileNew, delimiter=';')
    csv_readerOld = DictReader(csvFileOld, delimiter=',')
    return csv_readerNew, csv_readerOld, csvFileNew, csvFileOld

def writeUnknownRow(row_new, row):
    # old file only has these fields
    row['🖥️ My Office'] = ''
    row['Don\'t Do'] = 'No'
    row['Done'] = 'No'
    row['First Contact'] = ''
    row['Last contact'] = ''
    row['Contact'] = ''
    row['Notes'] = ''
    # new file has below fields
    row['Account info : Assessed'] = row_new['Account info : Assessed']
    row['Computer'] = row_new['Computer']
    row['Serial number'] = row_new['Serial number']
    row['Account info : AssetTagID'] = row_new['Account info : AssetTagID']
    row['Connected user'] = row_new['Connected user']
    row['Model'] = row_new['Model']
    row['Account info : Department'] = row_new['Account info : Department']
    row['Account info : Expiration Date'] = row_new['Account info : Expiration Date']
    row['IP address'] = row_new['IP address']
    row['Last inventory'] = row_new['Last inventory']
    row['Operating system'] = row_new['Operating system']

def writeKnownRow(row_new, row_old, row):
    # old file only has these fields
    row['🖥️ My Office'] = row_old['🖥️ My Office']
    row['Don\'t Do'] = row_old['Don\'t Do']
    row['Done'] = row_old['Done']
    row['First Contact'] = row_old['First Contact']
    row['Last contact'] = row_old['Last contact']
    row['Contact'] = row_old['Contact']
    row['Notes'] = row_old['Notes']
    # new file has below fields
    row['Account info : Assessed'] = row_new['Account info : Assessed']
    row['Computer'] = row_new['Computer']
    row['Serial number'] = row_new['Serial number']
    row['Account info : AssetTagID'] = row_new['Account info : AssetTagID']
    row['Connected user'] = row_new['Connected user']
    row['Model'] = row_new['Model']
    row['Account info : Department'] = row_new['Account info : Department']
    row['Account info : Expiration Date'] = row_new['Account info : Expiration Date']
    row['IP address'] = row_new['IP address']
    row['Last inventory'] = row_new['Last inventory']
    row['Operating system'] = row_new['Operating system']

def usage(message, code):
    print(message)
    print("See user manual for more information.")
    sys.exit(code)

if __name__ == '__main__':
    main()
